$('.slider-principal').slick({
    dots: true,
    infinite:true,
    speed:300,
    slidesToshow:4,
    autoplay:true,
    autoplaySpeed:2000
});

