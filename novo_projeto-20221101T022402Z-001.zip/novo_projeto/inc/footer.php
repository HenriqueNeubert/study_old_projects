


        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
        <script src="assets/js/plugins/slick/slick.min.js"></script>
        <!--
        <script>window.jQuery || document.write('<script src="assets/js/vendor/jquery-1.11.2.min.js"><\/script>')</script>
        <script src="assets/js/plugins/imagesloaded.pkgd.js"></script>
        <script src="assets/js/plugins/jquery.placeholder-min.js"></script>
        -->
        <!-- EDIT -->
        <script src="assets/js/plugins/lightbox/html5lightbox.js"></script>
        <script src="assets/js/plugins/jquery.mask.min.js"></script>
        <script src="assets/js/main.js"></script>
        <script src="assets/js/cycle.js"></script>
        <script src="assets/js/plugins/slick/scripts.js"></script>
    </body>
</html>
