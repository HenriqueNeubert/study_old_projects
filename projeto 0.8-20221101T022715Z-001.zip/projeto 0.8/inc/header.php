<!doctype html>
<html lang="pt-br">

<head>

    <title></title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="style.css">
    <title>Projeto Seis - PS</title>
    <meta charset="utf-8">
    <meta name=viewport content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/style.css" type="text/css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700;900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@500;600&family=Lobster&display=swap" rel="stylesheet">

</head>
<body>
    <header class="w-100">

    </header>
