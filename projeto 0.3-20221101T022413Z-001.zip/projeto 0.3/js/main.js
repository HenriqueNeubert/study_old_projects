$('.slider-principal').slick({
    dots: true,
    infinite:true,
    speed:300,
    slidesToShow:1,
    adaptiveHeight:true,
    autoplay: true,
    autoplayspeed:2000
});